import '../models/bond_model.dart';

/// Global in-memory bond store
final List<BondModel> bondsList = [];
