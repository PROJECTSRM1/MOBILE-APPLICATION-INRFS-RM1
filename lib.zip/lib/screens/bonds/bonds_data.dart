import '../../models/bond_model.dart';

final List<BondModel> bondsList = [];
